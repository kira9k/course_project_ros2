#!/bin/bash

IMAGE_NAME="ros2_course_project"

docker build -t $IMAGE_NAME .
